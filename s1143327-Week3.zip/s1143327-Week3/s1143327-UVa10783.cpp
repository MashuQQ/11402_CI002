#include<iostream>
using namespace std;
int main(){
    int a,b,c,i;
    i=0;
    cin>>a;
while(cin>>b){
if(a % 2 != 0 && a <= b && b % 2 != 0){
c=a;
for(a;a<b;a){
    a+=2;
    c+=a;
}
i++;
cout<<"Case "<<i<<": "<<c<<endl;
}
else{
    a=b;
}
}
return 0;
}
