#include<iostream>
using namespace std;
int main(){
int a,b,c,i;
while(cin >> a >> b){
    i=a;
    c=0;
    for(a;c < b;a++){
        c+=a;
        i++;
    }
    i--;
    cout <<i<<endl;
}
return 0;
}
