#include<iostream>
using namespace std;
int main(){
int a,b;
while(cin>>a){
    if(a==0)break;
b=0;
b+=a*a;
while(a>1){
    a--;
    b+=a*a;
}
cout <<b<<endl;
}
}
